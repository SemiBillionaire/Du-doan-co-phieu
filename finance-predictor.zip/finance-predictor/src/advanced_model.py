"""
Mô hình dự báo tài chính tiên tiến
==================================
Sử dụng kết hợp nhiều phương pháp tiên tiến để đạt độ chính xác cao nhất
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from scipy import stats
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.linear_model import LinearRegression, HuberRegressor, TheilSenRegressor, RANSACRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.model_selection import TimeSeriesSplit
import warnings

# Bỏ qua các cảnh báo không cần thiết
warnings.filterwarnings("ignore")

# Đường dẫn đầu ra
OUTPUT_DIR = Path("output")
OUTPUT_DIR.mkdir(exist_ok=True)

class AdvancedFinancialForecaster:
    """
    Lớp dự báo tài chính tiên tiến kết hợp nhiều phương pháp
    """
    
    def __init__(self, seasonality=4):
        """
        Khởi tạo mô hình dự báo
        
        Args:
            seasonality: Độ dài chu kỳ mùa vụ (4 quý cho dữ liệu quý)
        """
        self.seasonality = seasonality
        self.models = {
            "linear": LinearRegression(),
            "huber": HuberRegressor(epsilon=1.35, max_iter=200),
            "theil_sen": TheilSenRegressor(random_state=42, max_iter=300),
            "ransac": RANSACRegressor(random_state=42),
            "rf": RandomForestRegressor(n_estimators=100, random_state=42),
            "gbr": GradientBoostingRegressor(n_estimators=100, random_state=42)
        }
        
        # Các trọng số cho mô hình kết hợp (sẽ được cập nhật dựa trên hiệu suất)
        self.weights = {model: 1/len(self.models) for model in self.models}
        
        # Bộ chuẩn hóa dữ liệu
        self.scaler = RobustScaler()
        
        # Lưu các mô hình đã huấn luyện
        self.trained_models = {}
        
    def _create_features(self, data):
        """
        Tạo đặc trưng từ dữ liệu chuỗi thời gian
        
        Args:
            data: Series dữ liệu chuỗi thời gian
            
        Returns:
            X: Đặc trưng
            y: Giá trị mục tiêu
        """
        # Xử lý giá trị NaN
        data = data.copy()
        data = data.fillna(method='ffill').fillna(method='bfill')
        
        df = pd.DataFrame()
        
        # Tạo đặc trưng lag (giá trị trễ)
        for i in range(1, min(5, len(data)//2)):
            df[f'lag_{i}'] = data.shift(i)
        
        # Tạo đặc trưng xu hướng
        df['trend'] = np.arange(len(data))
        
        # Tạo đặc trưng mùa vụ
        for i in range(1, self.seasonality):
            df[f'season_{i}'] = (np.arange(len(data)) % self.seasonality == i).astype(int)
        
        # Tạo đặc trưng biến động
        if len(data) >= 3:
            df['volatility'] = data.rolling(3).std().fillna(method='bfill')
        
        # Tạo đặc trưng tăng trưởng
        if len(data) >= 4:
            df['growth_rate'] = data.pct_change(4).fillna(0)
        
        # Xóa các dòng có giá trị NaN
        df['target'] = data
        df = df.dropna()
        
        # Tách đặc trưng và mục tiêu
        X = df.drop('target', axis=1)
        y = df['target']
        
        return X, y
    
    def _evaluate_models(self, X, y):
        """
        Đánh giá và tính toán trọng số cho các mô hình
        
        Args:
            X: Đặc trưng
            y: Giá trị mục tiêu
            
        Returns:
            weights: Trọng số cho mỗi mô hình
        """
        if len(X) < 8:  # Không đủ dữ liệu để thực hiện kiểm tra chéo
            return self.weights
        
        # Phân chia dữ liệu theo thời gian
        tscv = TimeSeriesSplit(n_splits=min(3, len(X)//3))
        
        scores = {model: [] for model in self.models}
        
        for train_idx, test_idx in tscv.split(X):
            X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
            y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]
            
            # Chuẩn hóa dữ liệu
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            for name, model in self.models.items():
                try:
                    model.fit(X_train_scaled, y_train)
                    y_pred = model.predict(X_test_scaled)
                    
                    # Tính điểm R² điều chỉnh
                    r2 = r2_score(y_test, y_pred)
                    if r2 < 0:  # Nếu mô hình tệ hơn dự đoán trung bình
                        r2 = 0
                    
                    # Sử dụng MAE điều chỉnh
                    mae = mean_absolute_error(y_test, y_pred)
                    max_val = max(abs(y_test.max()), abs(y_test.min()))
                    if max_val > 0:
                        norm_mae = 1 - (mae / max_val)  # Điểm số càng cao càng tốt
                    else:
                        norm_mae = 0
                    
                    # Kết hợp các độ đo
                    score = (r2 + norm_mae) / 2
                    scores[name].append(score)
                except Exception as e:
                    scores[name].append(0)
        
        # Tính trung bình
        avg_scores = {model: np.mean(s) if len(s) > 0 else 0 for model, s in scores.items()}
        
        # Chuẩn hóa để tạo trọng số (tổng = 1)
        total = sum(avg_scores.values())
        if total > 0:
            weights = {model: score/total for model, score in avg_scores.items()}
        else:
            weights = {model: 1/len(self.models) for model in self.models}
        
        return weights
    
    def fit(self, series):
        """
        Huấn luyện mô hình với dữ liệu chuỗi thời gian
        
        Args:
            series: Series dữ liệu chuỗi thời gian
            
        Returns:
            self: Đối tượng đã được huấn luyện
        """
        # Tạo đặc trưng
        X, y = self._create_features(series)
        
        if len(X) <= 1:
            # Không đủ dữ liệu để huấn luyện
            return self
        
        # Đánh giá và cập nhật trọng số
        self.weights = self._evaluate_models(X, y)
        
        # Huấn luyện mô hình với toàn bộ dữ liệu
        X_scaled = self.scaler.fit_transform(X)
        
        for name, model in self.models.items():
            try:
                model.fit(X_scaled, y)
                self.trained_models[name] = model
            except Exception as e:
                print(f"Lỗi khi huấn luyện mô hình {name}: {e}")
                # Sử dụng mô hình dự phòng (linear)
                if name != "linear":
                    try:
                        self.trained_models[name] = LinearRegression().fit(X_scaled, y)
                    except:
                        pass
        
        return self
    
    def predict(self, series, periods=16):
        """
        Dự báo giá trị tương lai
        
        Args:
            series: Series dữ liệu chuỗi thời gian
            periods: Số kỳ cần dự báo
            
        Returns:
            forecast: Mảng các giá trị dự báo
        """
        if not self.trained_models:
            # Nếu chưa huấn luyện, thực hiện huấn luyện
            self.fit(series)
        
        # Tạo đặc trưng từ dữ liệu hiện có
        X, _ = self._create_features(series)
        
        if len(X) == 0:
            # Không đủ dữ liệu để dự báo
            # Trả về một dự báo đơn giản (tăng tuyến tính)
            last_value = series.iloc[-1] if not pd.isna(series.iloc[-1]) else 0
            return last_value + np.arange(1, periods+1) * 0.01 * last_value
        
        # Dự báo từng bước
        forecasts = []
        current_data = series.copy()
        
        for i in range(periods):
            # Tạo đặc trưng cho bước hiện tại
            X_current, _ = self._create_features(current_data)
            
            if len(X_current) == 0:
                # Nếu không thể tạo đặc trưng, sử dụng giá trị cuối cùng
                last_value = current_data.iloc[-1]
                forecasts.append(last_value)
                current_data = pd.concat([current_data, pd.Series([last_value])])
                continue
            
            # Chuẩn hóa dữ liệu
            X_current_scaled = self.scaler.transform(X_current.iloc[[-1]])
            
            # Dự báo bằng mỗi mô hình và tính trung bình có trọng số
            predictions = []
            sum_weights = 0
            
            for name, model in self.trained_models.items():
                try:
                    pred = model.predict(X_current_scaled)[0]
                    if not np.isnan(pred) and not np.isinf(pred):
                        weight = self.weights.get(name, 0)
                        predictions.append((pred, weight))
                        sum_weights += weight
                except Exception as e:
                    continue
            
            # Tính trung bình có trọng số
            if predictions and sum_weights > 0:
                weighted_avg = sum(p * w for p, w in predictions) / sum_weights
            else:
                # Dự phòng: sử dụng giá trị cuối cùng
                weighted_avg = current_data.iloc[-1]
            
            # Áp dụng hiệu chỉnh nếu giá trị dự báo quá khác biệt
            last_value = current_data.iloc[-1]
            if abs(weighted_avg / last_value - 1) > 0.2:  # Nếu thay đổi quá 20%
                # Sử dụng giá trị trung vị giữa dự báo và giá trị cuối
                weighted_avg = (weighted_avg + last_value) / 2
            
            # Thêm vào dự báo
            forecasts.append(weighted_avg)
            
            # Cập nhật dữ liệu hiện tại với giá trị dự báo
            current_data = pd.concat([current_data, pd.Series([weighted_avg])])
        
        return np.array(forecasts)
    
    def evaluate_forecast(self, historical_series, forecast_values):
        """
        Đánh giá xu hướng dự báo
        
        Args:
            historical_series: Series dữ liệu lịch sử
            forecast_values: Mảng các giá trị dự báo
            
        Returns:
            dict: Kết quả đánh giá
        """
        # Lấy giá trị không phải NaN cuối cùng
        last_values = historical_series.dropna()
        if len(last_values) == 0:
            return {
                "trend": "Không xác định",
                "change_rate": 0,
                "confidence": 0,
                "last_value": 0,
                "forecast_value": forecast_values[-1] if len(forecast_values) > 0 else 0
            }
        
        last_value = last_values.iloc[-1]
        
        # Tính tỷ lệ thay đổi
        if len(forecast_values) > 0:
            forecast_end = forecast_values[-1]
            change_rate = (forecast_end - last_value) / last_value if last_value != 0 else 0
            
            # Phân tích xu hướng
            if change_rate > 0.05:
                trend = "Tăng"
            elif change_rate < -0.05:
                trend = "Giảm"
            else:
                trend = "Ổn định"
            
            # Tính độ tin cậy dựa trên độ ổn định của dự báo
            if len(forecast_values) >= 3:
                # Độ lệch chuẩn tương đối
                rel_std = np.std(forecast_values) / np.mean(np.abs(forecast_values)) if np.mean(np.abs(forecast_values)) > 0 else 1
                confidence = max(0, min(0.99, 1 - rel_std))  # Giới hạn trong khoảng [0, 0.99]
            else:
                confidence = 0.7  # Giá trị mặc định
            
            return {
                "trend": trend,
                "change_rate": change_rate,
                "confidence": confidence,
                "last_value": last_value,
                "forecast_value": forecast_end
            }
        else:
            return {
                "trend": "Không xác định",
                "change_rate": 0,
                "confidence": 0,
                "last_value": last_value,
                "forecast_value": last_value
            }
    
    def plot_forecast(self, historical_series, forecast_values, title, company_code, output_path=None):
        """
        Vẽ biểu đồ dự báo
        
        Args:
            historical_series: Series dữ liệu lịch sử
            forecast_values: Mảng các giá trị dự báo
            title: Tiêu đề biểu đồ
            company_code: Mã công ty
            output_path: Đường dẫn đầu ra (tùy chọn)
            
        Returns:
            str: Đường dẫn đến biểu đồ đã lưu
        """
        plt.figure(figsize=(12, 6))
        
        # Vẽ dữ liệu lịch sử
        plt.plot(range(len(historical_series)), historical_series.values, marker='o', 
                 label='Dữ liệu lịch sử', color='blue', linewidth=2)
        
        # Vẽ dữ liệu dự báo
        history_len = len(historical_series)
        forecast_range = range(history_len, history_len + len(forecast_values))
        plt.plot(forecast_range, forecast_values, marker='s', 
                 label='Dự báo', color='red', linestyle='--', linewidth=2)
        
        # Thêm vùng dự báo
        plt.axvspan(history_len - 0.5, history_len + len(forecast_values) - 0.5, 
                    alpha=0.2, color='gray', label='Khoảng dự báo')
        
        # Thông tin dự báo
        evaluation = self.evaluate_forecast(historical_series, forecast_values)
        change_text = f"Xu hướng: {evaluation['trend']} ({evaluation['change_rate']*100:.1f}%)"
        confidence_text = f"Độ tin cậy: {evaluation['confidence']*100:.1f}%"
        
        # Thêm thông tin vào biểu đồ
        plt.annotate(change_text, xy=(0.02, 0.95), xycoords='axes fraction', 
                    fontsize=10, backgroundcolor='white', bbox=dict(boxstyle="round,pad=0.3", edgecolor="gray", facecolor="white"))
        plt.annotate(confidence_text, xy=(0.02, 0.90), xycoords='axes fraction', 
                    fontsize=10, backgroundcolor='white', bbox=dict(boxstyle="round,pad=0.3", edgecolor="gray", facecolor="white"))
        
        # Định dạng đồ thị
        plt.title(f"{title} - {company_code}")
        plt.ylabel('Giá trị (VND)')
        plt.xlabel('Quý (từ Q1-2020 đến Q4-2028)')
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.legend()
        
        # Thêm nhãn x cho các năm
        years = ['2020', '2022', '2024', '2026', '2028']
        positions = [0, 8, 16, 24, 32]
        plt.xticks(positions, years)
        
        # Lưu biểu đồ
        if output_path is None:
            output_path = OUTPUT_DIR / f"{company_code}_{title.replace(' ', '_')}_forecast.png"
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
        
        return str(output_path)


def forecast_financial_indicator(historical_data, indicator_name, company_code, periods=16):
    """
    Dự báo chỉ số tài chính sử dụng mô hình tiên tiến
    
    Args:
        historical_data: DataFrame dữ liệu lịch sử
        indicator_name: Tên chỉ số cần dự báo
        company_code: Mã công ty
        periods: Số kỳ cần dự báo
        
    Returns:
        dict: Kết quả dự báo
    """
    if indicator_name not in historical_data.index:
        return None
    
    # Lấy chuỗi dữ liệu
    series = pd.Series(historical_data.loc[indicator_name])
    
    # Tạo và huấn luyện mô hình
    model = AdvancedFinancialForecaster(seasonality=4)  # 4 quý một năm
    
    # Dự báo
    forecast_values = model.predict(series, periods=periods)
    
    # Đánh giá xu hướng
    evaluation = model.evaluate_forecast(series, forecast_values)
    
    # Vẽ biểu đồ
    short_name = indicator_name.split("(")[0].strip()
    chart_path = model.plot_forecast(
        series, 
        forecast_values, 
        short_name, 
        company_code
    )
    
    # Thêm dữ liệu dự báo vào kết quả
    evaluation["forecast"] = forecast_values
    evaluation["chart_path"] = chart_path
    
    return evaluation 